package at.spengergasse.views.personal;

import com.vaadin.flow.component.Composite;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.router.Menu;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.vaadin.lineawesome.LineAwesomeIconUrl;

@PageTitle("Personal")
@Route("my-view")
@Menu(order = 2, icon = LineAwesomeIconUrl.TABLE_SOLID)
public class PersonalView extends Composite<VerticalLayout> {

    public PersonalView() {
        getContent().setWidth("100%");
        getContent().getStyle().set("flex-grow", "1");
    }
}
